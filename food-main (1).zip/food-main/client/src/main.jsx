import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';

// Boot and mount the React application inside the DOM root container
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Register service worker for PWA offline support
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => console.log('[PWA] Service Worker registered successfully: ', reg.scope))
      .catch((err) => console.error('[PWA] Service Worker registration failed: ', err));
  });
}
